#!/bin/bash
echo "Hello Lamiii!"